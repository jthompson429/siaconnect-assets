
Dataverse Table: KBData

Primary Name Column:
- Title (Text)

Columns:
- cr144_summary (Multiline Text)
- cr144_fullcontent (Multiline Text)
- cr144_productfamily (Choice or Text)
- cr144_category (Choice or Text)
- cr144_errorcode (Text)
- cr144_tags (Text)
- cr144_hasattachment (Yes/No)
- cr144_sharepointurl (URL)
- cr144_internalurl (URL)
- cr144_datecreated (Date & Time)
- cr144_lastupdated (Date & Time)

Recommended Choices:
- Category: Troubleshooting, Installation, Preventive Maintenance, Parts Replacement, Field Updates, Error Code Guide
- Product Family: CI-300X, CI-200, etc.
