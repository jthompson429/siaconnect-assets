# SIAConnect Demo Site (v1)

This is a static, local-first product site based on the HTML5UP "Photon" template.

## Structure:
- `index.html`: Homepage and navigation
- `/assets`: Folder for images, CSS, JS, and your final MP4 demo

## Instructions:
1. Open `index.html` in your browser to view the site.
2. Replace the placeholder video (`assets/videos/siaconnect-demo.mp4`) with your final exported video.
3. Customize text/images as needed to match final branding.

Built for internal demo use. No hosting required.

Enjoy!
